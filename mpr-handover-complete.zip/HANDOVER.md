# HANDOVER: MPR / MAA work (session of 2026-10-22)

Paste the prompt at the bottom into a new session. Everything it needs is in this
outputs folder (`/mnt/session/outputs/` of the old session). Upload the folder to the new
session if the new session doesn't share the filesystem.

## State
- Foundations: `MPR-FOUNDATIONS.adoc` (proof ladder R0–R8, JtV §7; proofs on paper, not mechanised).
- Plan: `ULTRAPLAN.adoc` (proof architecture ruling, Stages 0–4, Stage 0 progress table).
- Stage 0 patches, all unpushed, one directory per repo under `stage0-patches/`:
  - maa-framework (4 commits, branch `claude/mpr-foundations`): foundations, README scope/limits, glossary, ULTRAPLAN, absolute-zero pin bump to e249d7fb, `scripts/proof-debt-gate.sh` plus baseline.
  - absolute-zero (`claude/stage0-hygiene`): delete false `shannon_entropy_maximum` (archived Coq), rename `*_derived` → `*_postulate`.
  - jtv-lang (`claude/stage0-hygiene`): VACUITY NOTEs in `JtvSecurity.lean`, README/EXPLAINME corrections.
  - jtv-halting-islands-ct (`claude/stage0-hygiene`): Limitation 2 correction (LOOP / Bellantoni–Cook).
  - januskey (`claude/stage0-hygiene`): Principle → Principal rename (16 files).
- Not yet verified by building: Lean comment edits (jtv-lang), januskey `cargo check` after the rename.
- Open in Stage 0: wire `proof-debt-gate.sh` into CI (needs the sibling repos checked out).

## Decisions already made by the owner
- Theory in Agda `--safe --without-K`, minimal prelude (no stdlib) in the MPR kernel.
- Route A: Agda → Dedukti (Agda2Dedukti), re-checked by dkcheck/Kontroli. Route B: re-prove the statements in Lean 4 and Rocq.
- Engineering: Idris2 ABI; Rust plus Creusot (januskey, Aletheia); Ada/SPARK (obliterate primitive, valence-shell runtime core).
- echidna/echidnabot/proof-burrower development deferred until after Stage 1.
- New repo `mpr-kernel` for the Agda kernel.

## Prompt for the new session
> Continue the MPR ULTRAPLAN for the hyperpolymath estate. Read HANDOVER.md, ESTATE-PLAYBOOK.md §0, ULTRAPLAN.adoc
> and MPR-FOUNDATIONS.adoc first. (1) Apply each patch set in stage0-patches/ to its repo on
> the named branch, push, and open PRs. (2) Install Agda, Lean 4 (elan), Rocq (opam) and
> Agda2Dedukti plus dkcheck. Compile-check the jtv-lang Lean edits and januskey (`cargo check`),
> and fix anything that breaks. (3) Wire scripts/proof-debt-gate.sh into maa-framework CI.
> (4) Begin Stage 1: create mpr-kernel (Agda, --safe --without-K, minimal prelude) and mechanise
> 1.1–1.3 first, checking every proof. Keep proven / tested / conjectured separate, and update
> ULTRAPLAN's progress table as you go.

## Restoring the work (nothing was pushed from the old session)
Two equivalent copies are in this folder:
- `git-bundles/<repo>.bundle`: full commits with original hashes. In a clone of the repo:
  `git fetch /path/to/<repo>.bundle <branch>:<branch>` then `git push -u origin <branch>`.
  Branches: maa-framework `claude/mpr-foundations`; all others `claude/stage0-hygiene`.
- `stage0-patches/<repo>/*.patch`: apply with `git am` on a branch from `main`.
