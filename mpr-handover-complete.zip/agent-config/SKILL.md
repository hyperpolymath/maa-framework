---
name: hyperpolymath-proof-engineering
description: Use for any proof, formalisation or verified-engineering work in the hyperpolymath estate (maa-framework, absolute-zero, januskey, jtv-*, oblibeny, valence-shell, *-types repos). Covers toolchain setup, the Agda-first proof architecture, Dedukti/Lean/Rocq cross-checking, proof-debt rules, and how to report status honestly.
---

# Hyperpolymath proof engineering

## First actions in any session
1. Read `docs/foundations/ULTRAPLAN.adoc` and `docs/foundations/MPR-FOUNDATIONS.adoc` in maa-framework (or HANDOVER.md if supplied). The ULTRAPLAN progress table is the source of truth for what is done.
2. Check the toolchains. If any is missing, install it; never report a prover as "unavailable" without trying:
   - Agda: `ghcup` → `cabal install Agda` (target 2.8.x); the stdlib only where a repo already uses it.
   - Lean 4: `curl -sSf https://raw.githubusercontent.com/leanprover/elan/master/elan-init.sh | sh -s -- -y`
   - Rocq: `opam init -y && opam install -y rocq-prover` (or `coq`)
   - Dedukti: `opam install dedukti lambdapi`; Agda2Dedukti from https://github.com/Deducteam/Agda2Dedukti
   - Idris2, Z3, Rust (+Creusot), GNAT/SPARK as the task needs.
3. Check git push works (`git push --dry-run`) before promising to push.

## Proof architecture (owner ruling, 2026-10)
- Theory: Agda `{-# OPTIONS --safe --without-K #-}`. The MPR kernel (`mpr-kernel`) uses a **minimal prelude, no stdlib**, so that Agda2Dedukti can translate it.
- Route A (proof objects): Agda → Dedukti/Lambdapi, re-checked by dkcheck and Kontroli. Log each translation outcome (pass / fail + minimal repro) in `mpr-kernel/DEDUKTI-LOG.adoc`. Failures are candidate upstream contributions to Deducteam.
- Route B (statements): re-prove each kernel theorem independently in Lean 4 and Rocq. Statements must be transcribed faithfully; record the correspondence in a table.
- No direct Agda → Lean/Coq proof-object translation exists. Never claim one.
- Engineering: Idris2 at ABI boundaries; Rust verified with Creusot (januskey core, Aletheia); Ada/SPARK for the obliterate primitive and the valence-shell runtime core.
- Tool development (echidna, echidnabot, proof-burrower, BoJ cartridges) is deferred until after ULTRAPLAN Stage 1. Use the tools as they stand, and file friction as issues.

## Proof-debt rules
- Debt = `postulate`, `Axiom`/`Parameter`/`Conjecture`, `sorry`, `Admitted`, `believe_me`/`assert_total`, AND vacuous theorems (true by definition, stated over a hand-written labelling rather than the semantics, or about record literals).
- Run `scripts/proof-debt-gate.sh` (maa-framework) before every commit that touches proofs. Never raise a count. Lower the baseline with `--update` only in a dedicated commit.
- Mark vacuous theorems with `VACUITY NOTE (MPR ULTRAPLAN ...)` comments rather than silently deleting them.
- Archived trees (`archive/`) are not built. Do not cite them as evidence.

## Honesty in reporting
Use exactly these tags in docs, commits and reports:
- **PROVED (mechanised, <prover>)**: compiles in CI or was compiled this session; give the command.
- **PROVED (paper)**: argument written, not mechanised.
- **TESTED**: property or differential tests, not proof.
- **STANDARD**: cited result; give the reference.
- **CONJECTURE / OPEN**.
Never write "verified", "proven" or "mechanised" for anything you did not compile. When you edited a file you could not build, say so explicitly.

## Repo conventions
- Branches: `claude/<topic>`. Conventional commits. AsciiDoc for docs. SPDX headers on new files (MPL-2.0 for code, CC-BY-SA-4.0 for prose).
- README claims must have receipts in EXPLAINME.adoc. Update both together.
- Keep the MPR claim scoped: "no rhino *in the model*", with the named assumptions (MPR-FOUNDATIONS §5). Never "we know there is no rhino".
- Terminology: Maximal **Principal** Reduction (a principal is an authority-holder), not "Principle".

## Never
- Paste tokens into files, paths, commits or chat output. If you see a credential anywhere, stop and tell the user to revoke it.
- Force-push or rewrite published history without explicit permission.
- Edit `aletheia/.github/workflows/` expecting it to run (it is inert; gates go in the root `.github/workflows/`).
