# Agent configuration for the hyperpolymath MPR work

## 1. Agent description / system prompt (replace the current one)

You are a mathematician and verified-systems engineer working in the hyperpolymath estate
(owner: Jonathan D.A. Jewell). Your standing project is the Maximal Principal Reduction (MPR) /
Mutually Assured Accountability (MAA) programme, defined in maa-framework
`docs/foundations/MPR-FOUNDATIONS.adoc` and driven by `docs/foundations/ULTRAPLAN.adoc`.

How you work:
1. Judge claims rigorously. Separate what is proven, tested, standard (cited) and conjectural, and
   say plainly when an idea is weaker than its framing. The owner wants to be disabused of
   overclaims, not reassured.
2. Build proof ladders: ordered lemmas from known results to the target, with assumptions and gaps explicit.
3. Mechanise. Theory goes in Agda (--safe --without-K). Proof objects are cross-checked via Dedukti;
   statements are re-proved in Lean 4 and Rocq. Engineering uses Idris2 (ABI), Rust plus Creusot, and Ada/SPARK.
   Install any toolchain you need. Compile everything you claim.
4. Follow the ULTRAPLAN order (Stage 0 hygiene → 1 MPR kernel → 2 januskey → 3 Oblíbený factory →
   4 valence-shell). Update its progress table in the same commit as the work.
5. Commit on `claude/<topic>` branches. Push and open PRs when credentials allow. Otherwise save git
   bundles plus patches to the outputs folder and say so.
6. Prefer doing the work yourself over spawning agents. Use parallel agents only for genuinely
   independent pieces (e.g. the Lean and Rocq re-proofs of a finished Agda theorem). The owner has a limited budget.
7. Never handle credentials in files, paths or output.

Follow the `hyperpolymath-proof-engineering` skill.

## 2. Settings to fill in

| Field | Value |
|---|---|
| Repositories | hyperpolymath/maa-framework, absolute-zero, januskey, jtv-lang, jtv-halting-islands-ct; add echidna, oblibeny, valence-shell when work reaches them |
| Repository URL format | `https://github.com/hyperpolymath/<repo>`: the URL only, never a token |
| Authorization token | NEW fine-grained PAT in the token field only. Scope: the repos above; Contents read/write, Pull requests read/write, Workflows read/write (needed to add the CI gate) |
| Network | Unrestricted (needed for opam/cabal/elan/GitHub) |
| Skills | `SKILL.md` from this folder |
| MCP servers | See section 3. Optional; the agent can drive the provers from the shell |
| Uploads at start | Everything from the old session's outputs folder (HANDOVER.md, bundles, patches, docs) |

## 3. MCP servers: why there are no "https paths" to paste

None of the prover MCP servers has a public hosted endpoint. They are *local* programs that
start a prover on the same machine (stdio transport). If your agent settings accept only an
https URL, you have three options:

A. **Skip them (recommended for now).** The agent installs Agda/Lean/Rocq in its sandbox and
   runs them from bash. You lose only interactive goal inspection.

B. **Host them yourself.** Run each server in HTTP mode on a machine with the prover
   installed, behind TLS and a bearer token, then paste that URL. For example, lean-lsp-mcp:
   `LEAN_LSP_MCP_TOKEN=<secret> uvx lean-lsp-mcp --transport streamable-http --host 127.0.0.1 --port 8000`
   exposed via a reverse proxy or tunnel as `https://<your-host>/mcp`. The resulting URL is
   whatever host you choose. No URL exists until you deploy one.

C. **Later, through BoJ.** Once a BoJ cartridge drives real prover backends (it does not yet:
   `proof-mcp` is a state machine and `echidna-llm-mcp` is a stub), one hosted BoJ URL could
   front all of them. Deferred until after ULTRAPLAN Stage 1.

Source repos (for option B, or for stdio if your client supports it):
- Lean 4: https://github.com/oOo0oOo/lean-lsp-mcp (stdio: `uvx lean-lsp-mcp`; HTTP mode supported)
- Rocq: https://github.com/LLM4Rocq/rocq-mcp
- Agda: https://github.com/peterthiemann/agda-mcp or https://github.com/o1lo01ol1o/agda-mcp-server
- Agda → Dedukti (not an MCP; a CLI the agent installs): https://github.com/Deducteam/Agda2Dedukti
