# ESTATE PLAYBOOK: per-repo skills, handovers and warnings

Companion to `HANDOVER.md` and `agent-config/SKILL.md` (the shared skill, which every
session below should load). Each section is self-contained. Copy one into a new session's
prompt for work on that repo. "Read" means the session must read it before acting.
Status words follow the shared skill: PROVED (mechanised / paper), TESTED, STANDARD, OPEN.

---------------------------------------------------------------------------------------------------
## 0. Findings from the 2026-10-22 session (do not re-research these)

- **MPR theory** is in `MPR-FOUNDATIONS.adoc`. Key results (paper proofs):
  - footprint membership is decidable;
  - confinement holds only if the whole language is capability-safe;
  - the factory is a Galois connection, giving a unique least sublanguage per program;
  - least *task* authority is non-unique, and finding it is NP-complete (Hitting Set);
  - Σ=⊥ gives CNO modulo divergence/resources (this is `y_not_cno`);
  - trace confinement composes, but secrecy and obliteration (hyperproperties) do not;
  - injective ⇒ I(π;F)=H(π), so RMR and RMO cannot hold on the same data;
  - Turing-incompleteness is the wrong axis: authority × decidability tier is the right one.
- **JtV** is the first MPR instance (DATA = Σ⊥ + total; the diode is composition). Several
  `JtvSecurity.lean` theorems are vacuous. Injection safety comes from *no eval anywhere*, not from
  totality. Addition-only DATA lies in Presburger/LRA (decidable). LOOP and Bellantoni–Cook keep
  grammar-only certification.
- **absolute-zero upstream** has archived Coq/Lean/Isabelle/Mizar. The active stack is Agda (CNO,
  OND, EchoBridge; ~700 lines, uses the stdlib, zero postulates) plus Idris2 plus Z3.
- **echidna**: its Dedukti/Lambdapi exchange serialises echidna's *own* terms. It does NOT translate
  Agda proofs. The SMTCoq bridge is a stub. Useful parts: axiom-usage tracking, prover dispatch.
- **proof-burrower** indexes .thy/.v/.lean only (no Agda). **echidnabot**: proof-aware CI, a good fit later.
- **BoJ**: `proof-mcp` is a lifecycle state machine (does not invoke provers); `echidna-llm-mcp` is a
  stub that routes to Claude. Not usable for proving yet.
- **Cross-checking landscape**: Agda2Dedukti exists (research-grade, partial coverage). Dedukti has
  independent checkers (dkcheck, Kontroli, Lambdapi). There is no general Agda → Lean/Rocq proof
  translation (Logipedia covers only the STTfa fragment).
- **Prover MCPs** (local stdio, no hosted URLs): lean-lsp-mcp, LLM4Rocq/rocq-mcp,
  peterthiemann/agda-mcp, o1lo01ol1o/agda-mcp-server.
- **Security note**: an old token prefix `github_pat_11ABTSLTI0QYB…` remains in maa-framework's
  public history (pre-existing, removed from HEAD by ab53573). It is only a prefix; ensure that old token is revoked.

Not yet read by anyone (treat claims about them as unknown): oblibeny, valence-shell,
echo-types, choreographic-types, epistemic-types, secret-types, resource-algebra internals.

---------------------------------------------------------------------------------------------------
## 1. maa-framework (hub)

**Skills**: shared skill; AsciiDoc; GitHub Actions; Coq submodule hygiene.
**Handover**:
- Restore branch `claude/mpr-foundations` from `git-bundles/maa-framework.bundle` and push. It contains
  the foundations, README scope/limitations, glossary, ULTRAPLAN, the absolute-zero pin bump
  (87902bb → e249d7fb) and `scripts/proof-debt-gate.sh` plus baseline.
- Next: wire the gate into CI. Check out absolute-zero (submodule), januskey and jtv-lang in
  the workflow, run the gate, and add a mutation self-test (plant a `postulate`, expect failure).
- Keep the ULTRAPLAN progress table current. It is the estate's single status board for MPR.

**Beware**: `aletheia/.github/workflows/` is inert. The README lists 11 domains, but only the
ULTRAPLAN stages are active. The gate baseline depends on which directories are scanned, so use the same set everywhere.

---------------------------------------------------------------------------------------------------
## 2. mpr-kernel (new repo, ULTRAPLAN Stage 1)

**Skills**: Agda (--safe --without-K, no stdlib, own minimal prelude); logical relations; Agda2Dedukti;
Lean 4; Rocq.
**Handover**: does not exist yet. Create it and mechanise in this order:
1. 1.1 syntax, labelled semantics, footprint;
2. 1.2 first-order confinement;
3. 1.3 Galois connection / least sublanguage;
4. 1.6 DATA island theorems;
5. 1.5 graded `diverge` (retires `y_not_cno`);
6. 1.7 composition;
7. 1.8 injective ⇒ no obliteration;
8. 1.4 the R3 lemma;
9. 1.9 higher-order (last).

The calculus is *JtV-shaped*: CONTROL with capability-labelled effects, DATA islands at Σ=⊥,
and the diode as composition.
After each theorem: run Agda2Dedukti + dkcheck (log in `DEDUKTI-LOG.adoc`), then transcribe the
statement to Lean and Rocq and re-prove it (keep a correspondence table).

**Beware**: the vacuity trap. State theorems over the *operational semantics*, never over a
hand-written label function (that is exactly JtV's mistake). Exit gate: zero postulates.
Coordinate notation with absolute-zero's `CNO.agda` so Σ=⊥ ⇒ CNO can be linked.

---------------------------------------------------------------------------------------------------
## 3. absolute-zero

**Skills**: Agda (stdlib in use here), Idris2, Z3; Coq only for archived reading.
**Handover**:
- Restore branch `claude/stage0-hygiene` (bundle) and push. It deletes the false
  `shannon_entropy_maximum` and renames `cno_zero_energy_dissipation_derived` →
  `..._postulate` (archived Coq only).
- Then: model divergence as a graded capability in Agda CNO, so that the `y_not_cno` problem becomes
  a footprint fact (ties to mpr-kernel 1.5).

**Beware**: `archive/` is not built. The upstream gate is `proofs/verify-all-provers.sh`, and
PROOF-STATUS still contains historical six-prover text. The two pillars (CNO, OND) are co-equal: OND is
the "null disclosure" side and links to RMO.

---------------------------------------------------------------------------------------------------
## 4. januskey

**Skills**: Rust + Creusot; Agda (resource-algebra sibling, `verification/proofs/agda`); Idris2 ABI;
Zig FFI; epistemic-types (for RMO).
**Handover**:
- Restore branch `claude/stage0-hygiene` (bundle; Principle → Principal across 16 files). Run
  `cargo check`/`cargo test` before pushing. This was not confirmed in the old session, and the rename touches a
  Rust string literal and Cargo.toml.
- Stage 2 tasks (ULTRAPLAN 2.1–2.6): Σ_jk as a kernel signature; partition state into a reversible
  groupoid and an obliterable part (justified by R6); prove `ReversiblePair` per operation; restate
  RMO as an indistinguishability game; differential tests generated from the model; remove `unwrap()`s on covered paths.

**Beware**: `adversaryCannotKnow` holds only because `Knows Adversary` has no constructor (documented
honestly; it is not a security proof). Obliteration via crypto-shredding is *computational*, not
information-theoretic. There are 225 `unwrap()`s.

---------------------------------------------------------------------------------------------------
## 5. jtv-lang

**Skills**: Lean 4 (v4.12 lakefile in `jtv_proofs/`); Rust (jtv-core); Agda for the port.
**Handover**:
- Restore branch `claude/stage0-hygiene` (bundle): VACUITY NOTEs plus README/EXPLAINME corrections. Run
  `lake build` in `jtv_proofs/` before pushing (comment-only edits, but unverified).
- Then replace the vacuous theorems with real ones over `JtvOperational`: data confinement; diode
  noninterference (check whether `JtvTheorems` "state independence" already gives it); no-code-creation
  (the actual injection theorem).
- Later, per the architecture ruling, the JtV core is ported to Agda (inside mpr-kernel), and these
  Lean files become its Lean re-proof leg.

**Beware**: of the 7 number systems, Float and Symbolic break the decidable tier. Label each.
Don't credit totality with injection safety.

---------------------------------------------------------------------------------------------------
## 6. jtv-halting-islands-ct

**Skills**: Python (POC) / Rust (`src/main.rs`); grammar design; computability (LOOP, Bellantoni–Cook).
**Handover**:
- Restore branch `claude/stage0-hygiene` (bundle; Limitation 2 corrected).
- Optional next: add a LOOP-tier island grammar and a safe-recursion tier as separate grammar modules
  with negative tests, demonstrating the tier table in MPR-FOUNDATIONS §7.5. Attach a Presburger
  check (e.g. via Z3) to the addition-only tier.

**Beware**: keep the POC narrow, as its README insists. Each tier needs its own negative tests
(the diode-rejection tests are the point of the repo).

---------------------------------------------------------------------------------------------------
## 7. oblibeny (ULTRAPLAN Stage 3, do not start before the Stage 1 gate)

**Skills**: language design; Agda (spec / metatheory); Rust → WASM; secure compilation (RSP).
**Handover**: not read in the old session. First read the repo and reconcile it with
ULTRAPLAN Stage 3. The factory is two-axis: authority Σ (computed as α(P), the Galois closure) ×
island tier (addition-only / safe recursion / LOOP).
**Beware**: the IETF draft's "Turing-Incomplete Deployment Subset" framing is superseded (TI is
neither necessary nor sufficient). The binary-level claim needs Robust Safety Preservation (Abate et
al., CSF 2019), which stays OPEN; do not claim it.

---------------------------------------------------------------------------------------------------
## 8. valence-shell (ULTRAPLAN Stage 4, last)

**Skills**: Ada/SPARK (runtime core); information-flow types (secret-types); choreographic-types if distributed.
**Handover**: not read in the old session. The work is composition: pipeline authority = union of
the stages' authority (R5); exfiltration (read + send) must be rejected statically with an explanation in capability terms.
**Beware**: secrecy is a hyperproperty and does not compose. Each composite pipeline needs relational verification.

---------------------------------------------------------------------------------------------------
## 9. Types repos (echo-, choreographic-, epistemic-, secret-types) and resource-algebra

**Skills**: Agda; type theory; whatever each repo uses (not yet read).
**Handover**: only these are on the critical path:
- resource-algebra: graded loss is reused in mpr-kernel 1.5 and januskey.
- epistemic-types: januskey 2.4 (RMO as "adversary does not know").
- secret-types: valence-shell 4.2.

echo- and choreographic-types are *not* on the critical path. Do not spend budget there before the Stage 2 gate.
**Beware**: before reuse, audit each for vacuous theorems and postulates with the proof-debt gate.

---------------------------------------------------------------------------------------------------
## 10. echidna / echidnabot / proof-burrower / boj-server(-cartridges): deferred tooling

**Skills**: Rust, Julia, Idris2, Zig; MCP; CI bots.
**Handover**: deferred until after the Stage 1 gate by owner decision. Until then:
- calling echidna's axiom tracker from inside the maa gate is allowed if it can be called from the command line;
- log friction met by mpr-kernel as issues in these repos.

When this work resumes, the priorities are:
- a BoJ cartridge that really invokes provers;
- Agda indexing in proof-burrower;
- wrapping Agda2Dedukti and the Dedukti checkers in echidna's exchange layer.

**Beware**: don't describe echidna's Dedukti exporter as cross-prover proof translation.

---------------------------------------------------------------------------------------------------
## Generic prompt template for a per-repo session

> Work on hyperpolymath/<REPO>. Load the `hyperpolymath-proof-engineering` skill. Read
> ESTATE-PLAYBOOK.md §0 (findings: do not re-research) and §<N> (this repo), then
> ULTRAPLAN.adoc. Restore the listed branch from git-bundles/ if one is given, verify it builds,
> and push it. Then do the "next" items for this repo in order. Update ULTRAPLAN's progress table in
> maa-framework when a stage item changes state. Report what was compiled versus only edited.
